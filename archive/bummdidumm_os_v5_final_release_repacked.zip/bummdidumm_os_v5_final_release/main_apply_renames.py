import os
from datetime import datetime, timezone
import google.auth
from googleapiclient.discovery import build

from shared.sheets_helpers import SheetManager
from shared.state_helpers import StateTracker

CONTROL_SHEET_ID = os.environ.get("CONTROL_SHEET_ID")
ENABLE_SHARED_DRIVES = os.environ.get("ENABLE_SHARED_DRIVES", "true").lower() == "true"

def run_apply_renames():
    print("Starte Rename Job: Wende vorgeschlagene Namen an")
    if not CONTROL_SHEET_ID:
        raise ValueError("Missing CONTROL_SHEET_ID")

    credentials, _ = google.auth.default()
    drive_service = build("drive", "v3", credentials=credentials, cache_discovery=False)
    sheets_service = build("sheets", "v4", credentials=credentials, cache_discovery=False)

    sheet_mgr = SheetManager(sheets_service, CONTROL_SHEET_ID)
    state = StateTracker(sheet_mgr)

    state.set_val("current_phase", "APPLY_RENAMES")

    # Lese den Dedupe_Report für anstehende Renames
    rows = sheet_mgr.read_all_rows("Dedupe_Report")
    current_run_id = state.get_val("last_successful_run_id")

    if not current_run_id:
        state.log_error("RENAME", "SYSTEM", "", "NoRunID", "Kein aktueller Run_ID gefunden.")
        return

    processed = 0
    errors = 0

    for row in rows:
        if len(row) < 17 or row[0] == "run_utc": continue
        if row[1] != current_run_id: continue # Nur den letzten Run bearbeiten

        file_id = row[4]
        current_name = row[3]
        suggested_name = row[14]

        if suggested_name and suggested_name != current_name:
            try:
                params = {"supportsAllDrives": True} if ENABLE_SHARED_DRIVES else {}
                drive_service.files().update(
                    fileId=file_id,
                    body={"name": suggested_name},
                    **params
                ).execute()
                processed += 1
            except Exception as e:
                errors += 1
                state.log_error("RENAME", file_id, current_name, "UpdateError", str(e))

    state.log_run("RENAME", "SUCCESS", processed, errors)
    state.set_val("current_phase", "IDLE")

if __name__ == "__main__":
    run_apply_renames()
